package com.wms.service;

import com.wms.dao.StockDAO;
import com.wms.dao.StockDAOImpl;
import com.wms.exception.InsufficientStockException;

public class StockService {

    private StockDAO stockDAO = new StockDAOImpl();

    public void stockIn(int productId, int qty) throws Exception {
        int available = stockDAO.getAvailableStock(productId);

        if (available == 0) {
            stockDAO.addStock(productId, qty);
        } else {
            stockDAO.updateStock(productId, available + qty);
        }
    }

    public void stockOut(int productId, int qty) throws Exception {
        int available = stockDAO.getAvailableStock(productId);

        if (available < qty) {
            throw new InsufficientStockException("Insufficient stock available");
        }

        stockDAO.updateStock(productId, available - qty);
    }

    public void viewStock() throws Exception {
        stockDAO.viewStock();
    }
}
