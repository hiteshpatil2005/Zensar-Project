package com.wms.service;

import com.wms.dao.ProductDAO;
import com.wms.dao.ProductDAOImpl;

public class ProductService {
    private ProductDAO productDAO = new ProductDAOImpl();

    public void deleteProduct(int productId) throws Exception {
        if (!productDAO.productExists(productId)) {
            throw new Exception("Product does not exist");
        }
        productDAO.deleteProduct(productId);
    }
}
