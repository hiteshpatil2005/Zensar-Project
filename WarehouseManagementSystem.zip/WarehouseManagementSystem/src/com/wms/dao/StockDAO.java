package com.wms.dao;

public interface StockDAO {

    int getAvailableStock(int productId) throws Exception;
    void addStock(int productId, int qty) throws Exception;
    void updateStock(int productId, int qty) throws Exception;
    void viewStock() throws Exception;
}
