package com.wms.dao;

import com.wms.util.DBConnection;

import java.sql.*;

public class StockDAOImpl implements StockDAO {

    public int getAvailableStock(int productId) throws Exception {
        Connection con = DBConnection.getConnection();
        String sql = "SELECT quantity FROM stock WHERE product_id=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, productId);
        ResultSet rs = ps.executeQuery();

        int qty = rs.next() ? rs.getInt("quantity") : 0;
        con.close();
        return qty;
    }

    public void addStock(int productId, int qty) throws Exception {
        Connection con = DBConnection.getConnection();
        String sql = "INSERT INTO stock(product_id, quantity) VALUES (?, ?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, productId);
        ps.setInt(2, qty);
        ps.executeUpdate();
        con.close();
    }

    public void updateStock(int productId, int qty) throws Exception {
        Connection con = DBConnection.getConnection();
        String sql = "UPDATE stock SET quantity=? WHERE product_id=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, qty);
        ps.setInt(2, productId);
        ps.executeUpdate();
        con.close();
    }

    public void viewStock() throws Exception {
        Connection con = DBConnection.getConnection();
        String sql = "SELECT * FROM stock";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        System.out.println("Product ID\tQuantity");
        while (rs.next()) {
            System.out.println(
                rs.getInt("product_id") + "\t\t" +
                rs.getInt("quantity")
            );
        }
        con.close();
    }
}
