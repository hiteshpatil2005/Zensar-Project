package com.wms.dao;

import com.wms.model.Product;
import com.wms.util.DBConnection;

import java.sql.*;

public class ProductDAOImpl implements ProductDAO {

    @Override
    public void addProduct(Product product) throws Exception {
        Connection con = DBConnection.getConnection();
        String sql = "INSERT INTO product(name, price) VALUES (?, ?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, product.getName());
        ps.setDouble(2, product.getPrice());
        ps.executeUpdate();
        System.out.println("Product added successfully");
        con.close();
    }

    @Override
    public void viewProducts() throws Exception {
        Connection con = DBConnection.getConnection();
        String sql = "SELECT * FROM product";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        System.out.println("ID\tName\tPrice");
        while (rs.next()) {
            System.out.println(
                rs.getInt("product_id") + "\t" +
                rs.getString("name") + "\t" +
                rs.getDouble("price")
            );
        }
        con.close();
    }

    @Override
    public boolean productExists(int productId) throws Exception {
        Connection con = DBConnection.getConnection();
        String sql = "SELECT product_id FROM product WHERE product_id=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, productId);
        ResultSet rs = ps.executeQuery();
        boolean exists = rs.next();
        con.close();
        return exists;
    }

    @Override
    public void deleteProduct(int productId) throws Exception {
        Connection con = DBConnection.getConnection();

        String sql = "DELETE FROM product WHERE product_id=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, productId);

        int rows = ps.executeUpdate();
        if (rows > 0) {
            System.out.println("Product deleted successfully");
        } else {
            System.out.println("Product not found");
        }

        con.close();
    }
}
