package com.wms.main;

import com.wms.dao.ProductDAO;
import com.wms.dao.ProductDAOImpl;
import com.wms.service.ProductService;
import com.wms.service.StockService;
import com.wms.exception.InsufficientStockException;
import com.wms.model.Product;

import java.util.Scanner;

public class WarehouseApp {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ProductDAO productDAO = new ProductDAOImpl();
        ProductService productService = new ProductService();
        StockService stockService = new StockService();

        while (true) {
            System.out.println("\n===== WAREHOUSE MANAGEMENT SYSTEM =====");
            System.out.println("1. Add Product");
            System.out.println("2. View Products");
            System.out.println("3. Delete Product");
            System.out.println("4. Stock IN");
            System.out.println("5. Stock OUT");
            System.out.println("6. View Stock");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1:
                        sc.nextLine();
                        System.out.print("Product Name: ");
                        String name = sc.nextLine();
                        System.out.print("Price: ");
                        double price = sc.nextDouble();
                        productDAO.addProduct(new Product(name, price));
                        break;

                    case 2:
                        productDAO.viewProducts();
                        break;

                    case 3:
                        System.out.print("Enter Product ID to delete: ");
                        int delId = sc.nextInt();
                        productService.deleteProduct(delId);
                        break;

                    case 4:
                        System.out.print("Product ID: ");
                        int pidIn = sc.nextInt();
                        System.out.print("Quantity: ");
                        stockService.stockIn(pidIn, sc.nextInt());
                        break;

                    case 5:
                        System.out.print("Product ID: ");
                        int pidOut = sc.nextInt();
                        System.out.print("Quantity: ");
                        stockService.stockOut(pidOut, sc.nextInt());
                        break;

                    case 6:
                        stockService.viewStock();
                        break;

                    case 0:
                        System.exit(0);

                    default:
                        System.out.println("Invalid choice");
                }
            } catch (InsufficientStockException e) {
                System.out.println(e.getMessage());
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
