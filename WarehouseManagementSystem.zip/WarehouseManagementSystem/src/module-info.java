/**
 * 
 */
/**
 * 
 */
module WarehouseManagementSystem {
	requires java.sql;
}